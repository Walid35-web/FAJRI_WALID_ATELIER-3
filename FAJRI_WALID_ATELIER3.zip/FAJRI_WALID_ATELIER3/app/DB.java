import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import  android.content.ContentValues;
import android.content.Context;




public class DB extends SQLiteOpenHelper{
    public static final String DB_NAME = "atelier3";
    public static final int DB_VERSION = 1;
    //infos table livres
    public static final String TB_NAME = "informations";
    public static final String CL_ID = "id";
    public static final String CL_NAME = "first_name";
    public static final String CL_FAMILY = "family_name";
    public DB(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TB_NAME + " (" + CL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CL_NAME + " TEXT, " + CL_FAMILY + " TEXT);");
    }



    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){

}}