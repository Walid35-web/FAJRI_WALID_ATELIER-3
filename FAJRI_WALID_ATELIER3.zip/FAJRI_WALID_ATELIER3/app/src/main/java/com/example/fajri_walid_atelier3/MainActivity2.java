package com.example.fajri_walid_atelier3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;
import java.util.Set;

public class MainActivity2 extends AppCompatActivity {
    TextView namerecup,familyrecap;
    String prenom,nom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        familyrecap=findViewById(R.id.familyrecap);
        namerecup=findViewById(R.id.namerecup);DB database=new DB(MainActivity2.this);
        database.getReadableDatabase();
        List<info_pers>persons=database.ReccupInfos();

        for (info_pers person:persons){
            nom=person.getNom().toUpperCase();
            prenom=person.getPrenom().toUpperCase();
        }
        namerecup.setText(prenom);
        familyrecap.setText(nom);
    }
}