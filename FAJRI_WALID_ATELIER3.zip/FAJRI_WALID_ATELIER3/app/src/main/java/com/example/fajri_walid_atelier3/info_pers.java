package com.example.fajri_walid_atelier3;

public class info_pers {
    private String nom;
    private String prenom;

    public info_pers(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }
}

